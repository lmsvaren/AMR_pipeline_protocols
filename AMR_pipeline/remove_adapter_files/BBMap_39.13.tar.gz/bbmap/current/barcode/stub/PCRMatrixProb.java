package barcode.stub;

/**
 * PCRMatrix subclass.
 * 
 * @author Brian Bushnell
 * @date March 25, 2024
 *
 */
public class PCRMatrixProb extends PCRMatrixProbAbstract {
	
	public PCRMatrixProb(int a, int b, int c, boolean d) {}
	
}
